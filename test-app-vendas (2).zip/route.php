<?php

include "connection/crud.php";

$ret = array('error' => 'nada foi passado');

if (isset($_REQUEST['table'])) {
    $table = $_REQUEST['table'];

    if (isset($_REQUEST['opt'])) {
        $opt = $_REQUEST['opt'];

        if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];
        } else {
            $id = null;
        }

        if (isset($_REQUEST['params'])) {
            $data = $_REQUEST['params'];
        } else {
            $data = null;
        }

        include_once "routes/Item.php";

        $ret = routing($opt, $id, $data);

    } else {
        $ret = array("erro", "falta opt");
    }

} else {
    $ret = array("erro", "falta table");
}

print_r($ret);

function getAll($rows, $conditions)
{
    return select($GLOBALS['table'], $rows, $conditions);
}

function getById($id, $rows)
{
    if ($id == null) {
        return array('erro' => 'id nao enviado na requisicao');
    }
    return select($GLOBALS['table'], $rows, array('id = ' => $id));
}

function add($data)
{
    return insert($GLOBALS['table'], $data);
}

function edit($id, $data)
{
    return update($GLOBALS['table'], $id, $data);
}

function remove($id)
{
    return delete($GLOBALS['table'], $id);
}
