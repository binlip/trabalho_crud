<?php

$GLOBALS['ret'] = array('error' => 'faltando algum dado');

function routing($opt, $id, $data)
{
    if (isset($data['rows'])) {
        $rows = array();
        foreach ($data['rows'] as $key) {
            $rows[] = $key;
        }
    } else {
        $rows = [];
    }

    if (isset($data['conditions'])) {
        $conditions = array();
        foreach ($data['conditions'] as $key => $value) {
            $conditions[$value[0] . ' ' . $value[1]] = ($value[1] == 'LIKE' ? '%' . $value[2] . '%' : $value[2]);
        }
    } else {
        $conditions = [];
    }

    switch ($opt) {
        case 'getall':
            return getAll($rows, $conditions);
            break;
        case 'getbyid':
            return getById($id, $rows);
            break;
        case 'getbynome':
            return getByNome($rows, $conditions);
            break;
        case 'add':
            return add($data);
            break;
        case 'edit':
            return edit($id, $data);
            break;
        case 'remove':
            return remove($id);
            break;
        case 'login':
            return login($data);
        default:
            break;
    }
}

function getByNome($rows, $conditions)
{
    if ($conditions == null) {
        return array('erro' => 'nome nao enviado na requisicao');
    }
    return select('item', $rows, $conditions);
}

function login($data)
{
    $table = 'user';
    $rows = ['user'];

    if(isset($data['credentials']['user'])) {
        $user = $data['credentials']['user'];
    }
    if(isset($data['credentials']['pass'])) {
        $pass = $data['credentials']['pass'];
    }

    $conditions = array('username =' => $user, 'password =' => md5($pass));

    $r = select($table, $rows, $conditions);
    
    if(isset($r[0]['user'])) {
        return select('funcionario', array(), array('id=' => $r[0]['user']));
    } else {
        return array('erro' => 'username ou password incorretos');
    }
}
