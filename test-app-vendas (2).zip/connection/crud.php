<?php

function open_connection()
{
    include_once 'Connection.php';
    $connection = connect();
    return $connection;
}

function select($table, $rows, $conditions)
{
    $sql = 'SELECT ';
    if ($rows) {
        foreach ($rows as $index => $row) {
            $sql .= ($index == 0 ? ($row . ' ') : (', ' . $row));
        }
    } else {
        $sql .= ' * ';
    }
    $sql .= " FROM $table";
    $i = 0;
    foreach ($conditions as $condition => $value) {
        $sql .= ($i == 0 ? (' WHERE ' . $condition . '"' . $value . '"') : (' AND ' . $condition . '"' . $value . '"'));
        $i++;
    }
    $conn = open_connection();
    $ret = [];
    $stmt = $conn->query($sql);
    while ($row = $stmt->fetch()) {
        array_push($ret, $row);
    }
    $conn = null;
    return $ret;
}

function insert($table, $data)
{
    $rows = '';
    $values = '';
    $i = 0;
    foreach ($data as $row => $value) {
        if ($i + 1 == sizeof($data)) {
            $rows .= $row;
            $values .= '"' . $value . '"';
        } else {
            $rows .= $row . ', ';
            $values .= '"' . $value . '", ';
        }
        $i++;
    }
    $sql = "INSERT INTO $table($rows) VALUES($values)";
    $conn = open_connection();
    $ret = [];
    $stmt = $conn->prepare($sql);
    try {
        $stmt->execute();
        $ret[] = $stmt->rowCount();
        $conn = null;
    } catch (PDOException $error) {
        $ret = array('error' => $error);
    }
    return $ret;
}

function update($table, $id, $rows)
{
    $sql = "UPDATE $table SET ";
    $i = 0;
    foreach ($rows as $row => $value) {
        $sql .= ($i == 0 ? (' ' . $row . ' = "' . $value . '"') : (',  ' . $row . ' = "' . $value . '"'));
        $i++;
    }
    $sql .= " WHERE id = $id";
    $conn = open_connection();
    $ret = [];
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $ret = $stmt->rowCount() == 0 ? array($stmt->rowCount()) : select($table, array(), array('id =' => $id));
    $conn = null;
    return $ret;
}

function delete($table, $id)
{
    $ret = select($table, array(), array('id =' => $id));
    $sql = "DELETE FROM $table WHERE id = $id";
    try {
        $conn = open_connection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        // $ret[] = $stmt->rowCount();
        $conn = null;
    } catch (PDOException $erro) {
        $ret = array('error' => $erro);
    }
    return $ret;
}
